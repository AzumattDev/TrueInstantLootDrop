| `Version` | `Update Notes`                       |
|-----------|--------------------------------------|
| 1.0.1     | - Ability to remove death smoke/poof |
| 1.0.0     | - Initial Release                    |